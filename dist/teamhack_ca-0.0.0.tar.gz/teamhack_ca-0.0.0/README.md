# CA
C(ertificate) A(uthority)
==========

Better than VeriSign!

----------
Don't forget to edit /etc/ssl/openssl.cnf...
BPs would probably be to use a different cnf for the CA

`./ca.sh <name your CA>`

`cd /root/<name of your CA>`

`<original dir>/openssl.sh <hostname key,csr,crt to sign> sign`

----------
[![CircleCI](https://img.shields.io/circleci/build/github/InnovAnon-Inc/CA?color=%23FF1100&logo=InnovAnon%2C%20Inc.&logoColor=%23FF1133&style=plastic)](https://circleci.com/gh/InnovAnon-Inc/CA)
[![Repo Size](https://img.shields.io/github/repo-size/InnovAnon-Inc/CA?color=%23FF1100&logo=InnovAnon%2C%20Inc.&logoColor=%23FF1133&style=plastic)](https://github.com/InnovAnon-Inc/CA)
[![LoC](https://tokei.rs/b1/github/InnovAnon-Inc/CA?category=code)](https://github.com/InnovAnon-Inc/CA)
[![CodeFactor](https://www.codefactor.io/repository/github/InnovAnon-Inc/CA/badge)](https://www.codefactor.io/repository/github/InnovAnon-Inc/CA)

[![Latest Release](https://img.shields.io/github/commits-since/InnovAnon-Inc/CA/latest?color=%23FF1100&include_prereleases&logo=InnovAnon%2C%20Inc.&logoColor=%23FF1133&style=plastic)](https://github.com/InnovAnon-Inc/CA/releases/latest)
![Dependencies](https://img.shields.io/librariesio/github/InnovAnon-Inc/CA?color=%23FF1100&style=plastic)

[![License Summary](https://img.shields.io/github/license/InnovAnon-Inc/CA?color=%23FF1100&label=Free%20Code%20for%20a%20Free%20World%21&logo=InnovAnon%2C%20Inc.&logoColor=%23FF1133&style=plastic)](https://tldrlegal.com/license/unlicense#summary)

# Innovations Anonymous
Free Code for a Free World!
==========
![Corporate Logo](https://innovanon-inc.github.io/assets/images/logo.gif)

